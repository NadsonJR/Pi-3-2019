package com.anadson.diagnostico;

public class DiagTemp {
     double temp;

    DiagTemp( double temp){
        this.temp = temp;
    }
    public String mensagemTemp(){
        String resposta = "";
            if(temp == -1){
                resposta = "Temperatura inválida!";
            }else if (temp < 35){
                resposta = "temperatura está muito baixa (abaixo de 35 graus)";
            }else if (temp >= 36 && temp <=36.9){
                resposta = "a temperatura está controlada a (36.0 a 36.9)";
            }else if (temp >= 37 && temp <=37.8){
                resposta = " a temperatura deve ser observada (Febril, 37.0 a 37.8)";
            }else if (temp >37.8){
                resposta = " deve ser aplicado o medicamento (Febre, 37.8 ou acima)";
            }

        return resposta;
    }
}
