package com.anadson.diagnostico

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.temperatura.*

class Insert_activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.temperatura)

        val saveButton:Button = findViewById(R.id.salvar)

        saveButton.setOnClickListener{
            val temperatura = TempDigitada.text.toString().toDouble()
            val returnIntent:Intent = Intent()
            Log.d("Log Erro", temperatura.toString())
            returnIntent.putExtra("return_temp", temperatura)
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }
    }



    fun closeIntent(){
        val i = Intent(applicationContext,MainActivity::class.java)
        intent.putExtra("Diagnostico", 38.0)
        startActivityForResult(intent,12)
    }
}
