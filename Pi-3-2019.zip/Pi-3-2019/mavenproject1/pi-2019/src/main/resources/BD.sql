Select * From Livro
drop table Livro
use Pi_III